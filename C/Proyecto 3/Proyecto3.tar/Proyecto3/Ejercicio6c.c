#include <stdio.h>

void imprimeHola(void)
 {
    printf("Hola\n");
 }
 
void imprimeChau(void)
 {
    printf("Chau\n");
 }

int main (void)
 {
    imprimeHola();
    imprimeHola();
    imprimeChau();
    imprimeChau();
 }
